package FinalPackage;

import javafx.application.Application;

public class Order {
	int number = 0;
	ArrayList<IndividualOrder> orders = new ArrayList<IndividualOrder>();

	double totalPrice;

	Order(ArrayList<IndividualOrder> orders) {
		this.orders = orders;
	}

	public void processOrder() {
		Iterator<IndividualOrder> iterator = orders.iterator();

		while (iterator.hasNext()) {
			IndividualOrder indOrder = (IndividualOrder) iterator.next();
			double price = indOrder.getCost() * indOrder.getQuantity();
			totalPrice += price;
		}
		System.out.println("The total price is: " + totalPrice);
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public ArrayList<IndividualOrder> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<IndividualOrder> orders) {
		this.orders = orders;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
}
